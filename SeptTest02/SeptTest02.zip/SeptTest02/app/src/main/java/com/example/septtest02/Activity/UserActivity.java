package com.example.septtest02.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.septtest02.R;

public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

    }
}
